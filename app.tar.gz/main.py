import flet as ft
from assets.views.view_router import views_handler_mobile, views_handler_web


        


def main(page: ft.Page):
    page.title = "LuminusTechne"
    page.theme_mode = ft.ThemeMode.LIGHT
    

    def route_change(route, e=None):
        
        
        if page.width <= 900:
            page.views.clear()
            page.views.append(views_handler_mobile(page)[page.route])
            page.update()
        else:
            page.views.clear()
            page.views.append(views_handler_web(page)[page.route])
            page.update()
        
        

    def view_pop(view):
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)
        
    
    page.on_resize = route_change 
    page.on_route_change = route_change
    page.on_view_pop = view_pop
    page.go(page.route)
    
    


ft.app(target=main, assets_dir="assets")             